const Sequelize = require('sequelize');
const sequelize = new Sequelize('address', 'root', '{}root123', {
  host: 'localhost',
  dialect: 'mysql',

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },

  // SQLite only
  storage: 'path/to/database.sqlite',

  // http://docs.sequelizejs.com/manual/tutorial/querying.html#operators
  operatorsAliases: false
});


// 测试连接
sequelize.authenticate()
	.then(() => {
		console.log('Connection has been established successfully.');
	})
	.catch(err => {
		console.error('Unable to connect to the database:', err);
	});


	get_area(options = {}) {
		let area = options.area;
		sequelize.query('select * from areas where cityCode = (select code from cities where name = ?)',
		  { replacements: [options.area], type: sequelize.QueryTypes.SELECT }
		).then(projects => {
		  console.log(projects)
		}).catch(err => {
			if (options.failed && typeof options.failed === 'function') {
				options.failed(err)
			}
		});
// 	    let filter= JSON.parse(options.filter ? options.filter : {});
// 		sequelize.models.work.findAll({
// 			where: {
// 				title: 'hhh'
// 			},
// 	        raw: true
// 		}).then(res => {
// 			console.log(222222222222222);
// 			if (options.success && typeof options.success === 'function') {
// 				options.success(res)
// 			}
// 		}).catch(err => {
// 			if (options.failed && typeof options.failed === 'function') {
// 				options.failed(err)
// 			}
// 		});
	},
	get_street(options = {}) {
	    let area = options.area;
	    let street = options.street;
	    sequelize.query('select * from streets where cityCode = (select code from cities where name = ?) and areaCode = (select code from areas where name = ?)',
	      { replacements: [options.area, options.street], type: sequelize.QueryTypes.SELECT }
	    ).then(projects => {
	      console.log(projects)
	    }).catch(err => {
	    	if (options.failed && typeof options.failed === 'function') {
	    		options.failed(err)
	    	}
	    });
	}